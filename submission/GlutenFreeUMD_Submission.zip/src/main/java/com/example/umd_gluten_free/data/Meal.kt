package com.example.umd_gluten_free.data

data class Meal(
    var location: String ?= null,
    var name: String ?= null,
    var rating: Long
    )
